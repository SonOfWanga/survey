<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mysteryshopper</title>
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/jQuery.mCustomScrollbar.min.css">
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/daterangepicker.css">
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/nprogress.css">
<!-- <link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/animate.min.css"> -->
<link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/custom.min.css">
<!-- <link rel="stylesheet" type="text/css" href="{{ url('/')}}/assets/stylesheets/custom.css"> -->
<script type="text/javascript" src="{{ url('/')}}/assets/javascripts/jquery.min.js"></script>