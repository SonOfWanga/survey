
<!DOCTYPE html>
<html lang="en">
  <head>
    @include('layouts.includes.head')
  </head>

  <body class="login">
    <div>
        @yield('content')
    </div>
  </body>
</html>